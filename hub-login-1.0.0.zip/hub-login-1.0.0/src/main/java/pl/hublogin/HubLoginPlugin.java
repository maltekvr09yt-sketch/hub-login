package pl.hublogin;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class HubLoginPlugin extends JavaPlugin {

    private static final String CHANNEL = "hubvelocity:connect";

    @Override
    public void onEnable() {
        getServer().getMessenger().registerOutgoingPluginChannel(this, CHANNEL);

        if (getCommand("teleporthub") != null) {
            getCommand("teleporthub").setExecutor(this::teleportHub);
        }

        getLogger().info("Hub-Login 1.0.0 wlaczony.");
    }

    @Override
    public void onDisable() {
        getServer().getMessenger().unregisterOutgoingPluginChannel(this, CHANNEL);
    }

    private boolean teleportHub(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Ta komenda jest tylko dla graczy.");
            return true;
        }

        if (!player.hasPermission("hublogin.teleporthub")) {
            player.sendMessage(ChatColor.RED + "Nie masz uprawnien.");
            return true;
        }

        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("teleporthub");

        player.sendPluginMessage(this, CHANNEL, out.toByteArray());
        return true;
    }
}
