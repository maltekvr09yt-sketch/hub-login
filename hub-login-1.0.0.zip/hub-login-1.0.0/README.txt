HUB-LOGIN 1.0.0

Plugin na serwer backendowy (np. login).

Komenda:
  /teleporthub

Dzialanie:
- wysyla przez plugin messaging do Velocity wiadomosc "teleporthub";
- Velocity wybiera dostepny hub (hub1/hub2);
- limit na hubie i sprawdzanie dostepnosci sa obslugiwane przez Hub-Velocity.

Kanal:
  hubvelocity:connect

Wymagany plugin:
  Hub-Velocity 1.0.0 na proxy Velocity.

Java:
  21

Paper/Purpur:
  1.21.4
